@component("mail::message")

    #ТЕСТ ПЕНИСА

    ##Click [here]({{$url}})

@endcomponent

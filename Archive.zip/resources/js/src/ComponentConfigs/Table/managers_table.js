export const managers_table = [
    {label: 'ID', key: 'id', type: 'default', action: null, limit: 40},
    {label: 'Юзернейм', key: 'name', type: 'link', action: 'show', limit: 40},
    {label: 'Удаление', key: 'delete', type: 'button', action: 'delete', limit: 40},
];

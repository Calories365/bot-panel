<script setup>

</script>

<template>
    <div class="form-group">
        <label for="message">Сообщение</label>
        <textarea type="text" class="form-control" id="message" placeholder="Сообщение" name="message" required="" rows="10"></textarea>
    </div>
</template>

<style scoped lang="scss">

</style>

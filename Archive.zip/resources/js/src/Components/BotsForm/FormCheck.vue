<script setup>

</script>

<template>
    <div class="form-check">
        <input type="checkbox" class="form-check-input" id="exampleCheck1">
        <label class="form-check-label" for="exampleCheck1">Активен</label>
    </div>
</template>

<style scoped lang="scss">

</style>

<script setup>

</script>

<template>
    <div class="form-group">
        <label for="exampleInputEmail1">Имя</label>
        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
    </div>
</template>

<style scoped lang="scss">

</style>

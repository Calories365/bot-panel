<script setup>

</script>

<template>
    <button type="submit" class="btn btn-primary">
        <slot></slot>
    </button>
</template>

<style scoped lang="scss">

</style>

<script setup>

</script>

<template>
    <button type="submit" class="btn btn-warning">
        <slot></slot>
    </button>
</template>

<style scoped lang="scss">

</style>

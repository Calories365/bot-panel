<script setup>

</script>

<template>
    <button class="btn btn-primary">
        <slot></slot>
    </button>
</template>

<style scoped lang="scss">

</style>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Calories 365</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" href="/images/icons8-calories-80.png">
</head>
<body>
<div id="app"></div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</body>
</html>
<?php /**PATH /Applications/sites/calories-working/resources/views/app.blade.php ENDPATH**/ ?>
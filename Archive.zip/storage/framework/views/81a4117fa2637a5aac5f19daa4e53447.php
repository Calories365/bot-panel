<?php echo e($slot); ?>

<?php /**PATH /Applications/sites/calories-working/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>
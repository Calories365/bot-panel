<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Applications/sites/calories-working/resources/views/vendor/mail/text/button.blade.php ENDPATH**/ ?>